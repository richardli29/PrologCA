station(a).
station(b).
station(c).
station(d).
station(e).
station(f).
station(g).
station(h).
station(i).
station(j).
station(k).
station(l).
station(m).
station(n).
station(o).
station(p).
station(q).

line(red).
line(green).
line(blue).
line(purple).
line(yellow).

stop(red,1,a).
stop(red,2,c).
stop(red,3,e).
stop(red,4,i).
stop(red,5,m).
stop(red,6,q).

stop(green,1,g).
stop(green,3,c).
stop(green,5,h).
stop(green,7,p).
stop(green,2,b).
stop(green,4,e).
stop(green,6,l).

stop(blue,6,k).
stop(blue,1,d).
stop(blue,5,j).
stop(blue,3,i).
stop(blue,2,h).
stop(blue,4,m).

stop(purple,5,n).
stop(purple,4,j).
stop(purple,3,i).
stop(purple,2,l).
stop(purple,1,o).

stop(yellow,5,g).
stop(yellow,3,i).
stop(yellow,7,n).
stop(yellow,1,o).
stop(yellow,6,k).
stop(yellow,4,f).
stop(yellow,2,l).
stop(yellow,8,q).

ttime(red,1,2,2).
ttime(red,2,3,3).
ttime(red,3,4,1).
ttime(red,4,5,2).
ttime(red,5,6,2).

ttime(green,1,2,2).
ttime(green,2,3,1).
ttime(green,3,4,2).
ttime(green,4,5,2).
ttime(green,5,6,3).
ttime(green,6,7,2).

ttime(blue,1,2,3).
ttime(blue,2,3,2).
ttime(blue,3,4,3).
ttime(blue,4,5,4).
ttime(blue,5,6,2).

ttime(purple,1,2,2).
ttime(purple,2,3,2).
ttime(purple,3,4,3).
ttime(purple,4,5,2).

ttime(yellow,1,2,1).
ttime(yellow,2,3,1).
ttime(yellow,3,4,2).
ttime(yellow,4,5,1).
ttime(yellow,5,6,1).
ttime(yellow,6,7,1).
ttime(yellow,7,8,2).

%Question 1
multiple_lines(S):- %success as long as the lines are different
	stop(X,_,S),
	stop(Y,_,S),
	(X \= Y).
	
%Question 2
termini(L, S1, S2):-
	findall(X, stop(L,X,_), List), %get all stops from the line L
	stop(L, Min, S1),
	stop(L, Max, S2),
	(get_min(List, Min)), %get min value of list
	(get_max(List, Max)). %get max value of list
	
get_max([X], X).	
get_max([H|T], Max):-
	get_max(T, Max),
	H @< Max.

get_max([Max|T], Max):-
	get_max(T,X),
	X @< Max.

get_min([L|Ls], Min) :-
    get_min(Ls, L, Min).

get_min([], Min, Min).
get_min([L|Ls], Min0, Min) :-
    Min1 is min(L, Min0),
    get_min(Ls, Min1, Min). 

%Question 3
isort([],[]).
isort([H|T],L) :- isort(T,Ts), insert(H,Ts,L).

insert(X,[H|T],[H|Ti]) :- X > H, !, insert(X,T,Ti).
insert(X,L,[X|L]).

sort_stops(L, List):-
	findall(X, stop(L,X,_), Z),
	isort(Z, List).	 

list_stops(L, List):- 
	sort_stops(L, Li),
	maplist(stop(L),Li,List).
	
%Question 4
segmentTime(L,S1,S2,D):-
	stop(L,N1,S1),
	stop(L,N2,S2),
	ttime(L,N1,N2,D).
	
path(S1,S2,Path):- path_builder(S1,S2,[S1],Path).
path_builder(S,S,_,[]).
path_builder(S1,S2,Visited,Path):-
	segmentTime(L,S1,Sx,D),
	\+ member(Sx, Visited),
	Path=[segmentTime(L,S1,Sx,D)|New_Path],
	path_builder(Sx,S2,[Sx|Visited],New_Path).	

comb(L,A,B,Dist):-
	ttime(L,A,X,D),
	ttime(L,X,B,D2),
	Dist is D2 + D.
	
	
%Question 5	
easiest_path(S1,S2,Path):- 
	shortest_path(S1,S2,Path),
	length(Path,_),
	sort(Path,_),
	\+ easy_builder(S1,S2,Path).
easy_builder(S1,S2,ShortP):-
	shortest_path(S1,S2,ShortP),
	sort(ShortP, PSort),
	length(PSort, Plength),
	shortest_path(S1,S2,ShortP2),
	sort(ShortP2, P2Sort),
	length(P2Sort, P2length),
	Plength > P2length.

	
%Question 6
shortest_path(S1,S2,Path):- 
	path(S1,S2,Path),
	length(Path,_),
	\+ short_builder(S1,S2,Path).
short_builder(S1,S2,Path):-
	path(S1,S2,Path),
	length(Path, Plength),!,
	path(S1,S2,Path2),
	length(Path2, P2length),
	Plength > P2length.
	
%Question 7
	
list_sum([Item], Item).
list_sum([Item1,Item2 | Tail], Total) :-
   list_sum([Item1+Item2|Tail], Total).
   
fastest_path(S1,S2,Path):- 
	path(S1,S2,Path),
	list_sum(Path,_),
	\+ fast_builder(S1,S2,Path).
fast_builder(S1,S2,Path):-
	path(S1,S2,Path),!,
	list_sum(Path, P1),
	path(S1,S2,Path2),
	list_sum(Path2, P2),
	P1 @< P2.
	
	

	
	
	
	
	
	
	
	